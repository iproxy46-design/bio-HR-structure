import seed from "./seed.json";
export type Unit = {id:string; name:string; parent?:string; count?:number};
export type Employee = {id:string; name:string; role?:string; dept?:string; unit?:string|null; city?:string; phone?:string; email?:string; manager?:string; photoVersion?:string};
export type State = {units:Unit[]; employees:Employee[]};
export const initial: State = seed as State;
export function validate(value: unknown): value is State {
 if (!value||typeof value!=="object")return false;
 const s=value as State;
 if (!Array.isArray(s.units)||!Array.isArray(s.employees)||s.units.length>500||s.employees.length>2000||!s.units.length)return false;
 const ids=new Set<string>();
 for(const u of s.units){if(!u||typeof u.id!=="string"||typeof u.name!=="string"||!u.id||u.id.length>100||!u.name.trim()||u.name.length>160||ids.has(u.id))return false;ids.add(u.id)}
 for(const u of s.units){if(u.parent&&!ids.has(u.parent))return false;let seen=new Set<string>([u.id]),current=u;while(current.parent){if(seen.has(current.parent))return false;seen.add(current.parent);current=s.units.find(x=>x.id===current.parent)!}}
 const persons=new Set<string>();
 for(const p of s.employees){if(!p||typeof p.id!=="string"||!p.id||typeof p.name!=="string"||!p.name.trim()||p.name.length>160||persons.has(p.id)||p.unit&&!ids.has(p.unit))return false;persons.add(p.id);for(const key of ['role','dept','city','phone','email','manager'] as const){if(p[key]&&String(p[key]).length>250)return false}if(p.photoVersion&&(!/^\d{1,20}$/.test(p.photoVersion)))return false}
 return JSON.stringify(s).length<1_000_000;
}
