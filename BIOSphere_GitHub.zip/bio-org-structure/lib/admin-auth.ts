import {env} from "cloudflare:workers";
import {pbkdf2Sha256} from "./pbkdf2";

const cookieName="__Host-biosfera_admin";
const enc=new TextEncoder();
const bytes=(s:string)=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const url64=(arr:ArrayBuffer)=>btoa(String.fromCharCode(...new Uint8Array(arr))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
function secret(){if(!env.ADMIN_SESSION_KEY)throw Error("Admin session is not configured");return env.ADMIN_SESSION_KEY}
function record(){if(!env.ADMIN_PASSWORD_RECORD||!env.ADMIN_USERNAME)throw Error("Admin login is not configured");return {username:env.ADMIN_USERNAME,record:env.ADMIN_PASSWORD_RECORD}}
async function signer(){return crypto.subtle.importKey("raw",enc.encode(secret()),{name:"HMAC",hash:"SHA-256"},false,["sign","verify"])}
export function sameOrigin(request:Request){const origin=request.headers.get("origin");return !!origin&&origin===new URL(request.url).origin}
export async function verifyPassword(username:string,password:string){const {username:configured,record:r}=record();const [salt,expected]=r.split(":");if(!salt||!expected||username!==configured)return false;const correct=bytes(expected);if(correct.length!==32)return false;const actual=pbkdf2Sha256(enc.encode(password),bytes(salt),310000);let diff=0;for(let i=0;i<32;i++)diff|=actual[i]^correct[i];return diff===0}
function usernameToken(){return url64(enc.encode(env.ADMIN_USERNAME).buffer)}
export async function sessionCookie(){const expiry=Date.now()+12*60*60*1000;const data=`${usernameToken()}.${expiry}`;const signature=url64(await crypto.subtle.sign("HMAC",await signer(),enc.encode(data)));return `${cookieName}=${data}.${signature}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=43200`}
export function clearSessionCookie(){return `${cookieName}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`}
export async function isAdmin(request:Request){try{const cookie=request.headers.get("cookie")?.split(/;\s*/).find(x=>x.startsWith(`${cookieName}=`))?.slice(cookieName.length+1);if(!cookie)return false;const match=cookie.match(/^([a-zA-Z0-9_-]+)\.(\d{13})\.([a-zA-Z0-9_-]+)$/);if(!match||match[1]!==usernameToken()||Number(match[2])<Date.now())return false;const signature=match[3].replace(/-/g,"+").replace(/_/g,"/");const padded=signature+"=".repeat((4-signature.length%4)%4);return await crypto.subtle.verify("HMAC",await signer(),bytes(padded),enc.encode(`${match[1]}.${match[2]}`))}catch{return false}}
