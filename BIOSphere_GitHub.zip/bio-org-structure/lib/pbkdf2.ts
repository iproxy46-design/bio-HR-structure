// PBKDF2-HMAC-SHA256 for runtimes where PBKDF2 is unavailable in WebCrypto.
// Password records use 310000 rounds and a 32-byte derived key.
const K=new Uint32Array([
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
]);
const rotr=(v:number,n:number)=>v>>>n|v<<32-n;

function sha256(message:Uint8Array):Uint8Array{
  const padded=new Uint8Array(Math.ceil((message.length+9)/64)*64);
  padded.set(message);
  padded[message.length]=0x80;
  const view=new DataView(padded.buffer);
  const bits=message.length*8;
  view.setUint32(padded.length-8,Math.floor(bits/0x100000000));
  view.setUint32(padded.length-4,bits>>>0);
  const h=new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
  const w=new Uint32Array(64);
  for(let offset=0;offset<padded.length;offset+=64){
    for(let i=0;i<16;i++)w[i]=view.getUint32(offset+i*4);
    for(let i=16;i<64;i++){
      const a=w[i-15],b=w[i-2];
      w[i]=(w[i-16]+(rotr(a,7)^rotr(a,18)^a>>>3)+w[i-7]+(rotr(b,17)^rotr(b,19)^b>>>10))>>>0;
    }
    let [a,b,c,d,e,f,g,q]=h;
    for(let i=0;i<64;i++){
      const t1=(q+(rotr(e,6)^rotr(e,11)^rotr(e,25))+(e&f^~e&g)+K[i]+w[i])>>>0;
      const t2=((rotr(a,2)^rotr(a,13)^rotr(a,22))+(a&b^a&c^b&c))>>>0;
      q=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;
    }
    h[0]=(h[0]+a)>>>0;h[1]=(h[1]+b)>>>0;h[2]=(h[2]+c)>>>0;h[3]=(h[3]+d)>>>0;
    h[4]=(h[4]+e)>>>0;h[5]=(h[5]+f)>>>0;h[6]=(h[6]+g)>>>0;h[7]=(h[7]+q)>>>0;
  }
  const result=new Uint8Array(32),out=new DataView(result.buffer);
  for(let i=0;i<8;i++)out.setUint32(i*4,h[i]);
  return result;
}

export function pbkdf2Sha256(password:Uint8Array,salt:Uint8Array,iterations:number):Uint8Array{
  if(!Number.isSafeInteger(iterations)||iterations<1)throw Error("Invalid PBKDF2 iterations");
  const key=password.length>64?sha256(password):password;
  const innerPad=new Uint8Array(64),outerPad=new Uint8Array(64);
  innerPad.fill(0x36);outerPad.fill(0x5c);
  for(let i=0;i<key.length;i++){innerPad[i]^=key[i];outerPad[i]^=key[i]}
  const outer=new Uint8Array(96);
  outer.set(outerPad);
  const first=new Uint8Array(68+salt.length);
  first.set(innerPad);first.set(salt,64);first.set([0,0,0,1],64+salt.length);
  const repeated=new Uint8Array(96);
  repeated.set(innerPad);
  const hmac=(input:Uint8Array)=>{
    outer.set(sha256(input),64);
    return sha256(outer);
  };
  let block=hmac(first);
  const result=block.slice();
  for(let i=1;i<iterations;i++){
    repeated.set(block,64);
    block=hmac(repeated);
    for(let j=0;j<32;j++)result[j]^=block[j];
  }
  return result;
}
