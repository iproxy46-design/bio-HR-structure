declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
  }
}
declare namespace Cloudflare { interface Env {
  ADMIN_USERNAME?: string;
  ADMIN_PASSWORD_RECORD?: string;
  ADMIN_SESSION_KEY?: string;
}}
