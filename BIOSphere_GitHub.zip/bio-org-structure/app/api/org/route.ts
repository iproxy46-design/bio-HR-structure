import { env } from "cloudflare:workers";
import { isAdmin,sameOrigin } from "../../../lib/admin-auth";
import { initial,validate } from "../../../lib/org";
import type { State } from "../../../lib/org";
function binding(){if(!env.DB)throw Error("Database unavailable");return env.DB}
export async function GET(request:Request){try{const row=await binding().prepare("SELECT payload FROM org_data WHERE id=1").first<{payload:string}>();return Response.json({state:row?JSON.parse(row.payload):initial,canEdit:await isAdmin(request)},{headers:{"Cache-Control":"no-store"}})}catch{return Response.json({error:"Не удалось загрузить структуру"},{status:503})}}
export async function PUT(request:Request){if(!sameOrigin(request)||!(await isAdmin(request)))return Response.json({error:"Редактирование доступно только администратору"},{status:403});try{const body=await request.json() as State;if(!validate(body))return Response.json({error:"Проверьте заполнение и подчинённость"},{status:400});await binding().prepare("INSERT INTO org_data (id,payload,updated_at) VALUES (1,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at").bind(JSON.stringify(body),new Date().toISOString()).run();return Response.json({ok:true})}catch{return Response.json({error:"Не удалось сохранить изменения"},{status:503})}}
