import {env} from "cloudflare:workers";
import {isAdmin,sameOrigin} from "../../../../lib/admin-auth";
function bucket(){if(!env.BUCKET)throw Error("Photo storage unavailable");return env.BUCKET}
function valid(id:string){return /^[a-zA-Z0-9_-]{1,100}$/.test(id)}
function typeOf(bytes:Uint8Array){
 if(bytes.length>=3&&bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff)return "image/jpeg";
 if(bytes.length>=8&&[137,80,78,71,13,10,26,10].every((n,i)=>bytes[i]===n))return "image/png";
 if(bytes.length>=12&&String.fromCharCode(...bytes.slice(0,4))==="RIFF"&&String.fromCharCode(...bytes.slice(8,12))==="WEBP")return "image/webp";
 return null;
}
export async function GET(_request:Request,{params}:{params:Promise<{id:string}>}){
 const {id}=await params;if(!valid(id))return new Response("Invalid id",{status:400});
 try{const obj=await bucket().get(`photos/${id}`);if(!obj)return new Response("Not found",{status:404});return new Response(obj.body,{headers:{"Content-Type":obj.httpMetadata?.contentType||"image/jpeg","Cache-Control":"no-store","X-Content-Type-Options":"nosniff"}})}catch{return new Response("Photo unavailable",{status:503})}
}
export async function POST(request:Request,{params}:{params:Promise<{id:string}>}){
 if(!sameOrigin(request)||!(await isAdmin(request)))return Response.json({error:"Недостаточно прав"},{status:403});
 const {id}=await params;if(!valid(id))return Response.json({error:"Некорректный ID"},{status:400});
 try{const form=await request.formData(),file=form.get("photo");if(!(file instanceof File)||file.size>5_000_000||file.size===0)return Response.json({error:"Выберите фото JPEG, PNG или WebP до 5 МБ"},{status:400});const bytes=new Uint8Array(await file.arrayBuffer()),contentType=typeOf(bytes);if(!contentType)return Response.json({error:"Поддерживаются JPEG, PNG и WebP"},{status:400});await bucket().put(`photos/${id}`,bytes,{httpMetadata:{contentType}});return Response.json({photoVersion:String(Date.now())})}catch{return Response.json({error:"Не удалось загрузить фото"},{status:503})}
}
export async function DELETE(request:Request,{params}:{params:Promise<{id:string}>}){
 if(!sameOrigin(request)||!(await isAdmin(request)))return Response.json({error:"Недостаточно прав"},{status:403});
 const {id}=await params;if(!valid(id))return Response.json({error:"Некорректный ID"},{status:400});
 try{await bucket().delete(`photos/${id}`);return new Response(null,{status:204})}catch{return Response.json({error:"Не удалось удалить фото"},{status:503})}
}
