import {env} from "cloudflare:workers";
import {sameOrigin,sessionCookie,verifyPassword} from "../../../../lib/admin-auth";
const failure=()=>Response.json({error:"Неверный логин или пароль"},{status:401});
export async function POST(request:Request){
 if(!sameOrigin(request))return Response.json({error:"Недопустимый запрос"},{status:403});
 let stage="database";
 try{
  if(!env.DB)throw Error("Database unavailable");
  const ip=request.headers.get("cf-connecting-ip")||"unknown";
  const row=await env.DB.prepare("SELECT failures,updated_at,blocked_until FROM login_attempts WHERE ip=?").bind(ip).first<{failures:number;updated_at:number;blocked_until:number}>();
  const now=Date.now();if(row&&row.blocked_until>now)return Response.json({error:"Слишком много попыток. Повторите через 15 минут"},{status:429});
  stage="password-check";
  const body=await request.json() as {username?:string;password?:string};
  const username=String(body.username||"").slice(0,100),password=String(body.password||"").slice(0,200);
  if(!(await verifyPassword(username,password))){
   stage="rate-limit";
   const count=row&&now-row.updated_at<15*60*1000?row.failures+1:1;
   await env.DB.prepare("INSERT INTO login_attempts (ip,failures,updated_at,blocked_until) VALUES (?,?,?,?) ON CONFLICT(ip) DO UPDATE SET failures=excluded.failures,updated_at=excluded.updated_at,blocked_until=excluded.blocked_until").bind(ip,count,now,count>=5?now+15*60*1000:0).run();
   return failure();
  }
  stage="clear-attempts";
  await env.DB.prepare("DELETE FROM login_attempts WHERE ip=?").bind(ip).run();
  stage="session";
  const cookie=await sessionCookie();
  return Response.json({ok:true},{headers:{"Set-Cookie":cookie,"Cache-Control":"no-store"}});
 }catch(e){console.error("Admin login failed at",stage,e instanceof Error?e.name:"unknown");return Response.json({error:"Вход временно недоступен"},{status:503})}
}
