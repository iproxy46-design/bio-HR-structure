import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
export const orgData = sqliteTable("org_data", {
  id: integer("id").primaryKey(),
  payload: text("payload").notNull(),
  updatedAt: text("updated_at").notNull(),
});
export const admins = sqliteTable("admins", {
  userId: text("user_id").primaryKey(),
  createdAt: text("created_at").notNull(),
});
export const loginAttempts = sqliteTable("login_attempts", {
  ip: text("ip").primaryKey(),
  failures: integer("failures").notNull(),
  updatedAt: integer("updated_at").notNull(),
  blockedUntil: integer("blocked_until").notNull(),
});
